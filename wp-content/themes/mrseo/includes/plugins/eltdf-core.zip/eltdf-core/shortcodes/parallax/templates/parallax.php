<div class="eltdf-parallax-holder <?php echo esc_attr($holder_class); ?>" <?php echo mrseo_elated_get_inline_attrs($holder_data); ?> <?php echo mrseo_elated_get_inline_style($holder_style); ?>>
	<div class="eltdf-parallax-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>
