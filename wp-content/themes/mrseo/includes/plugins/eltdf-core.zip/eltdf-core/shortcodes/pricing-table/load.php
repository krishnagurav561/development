<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/pricing-table/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/pricing-table/pricing-tables.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/pricing-table/pricing-table.php';