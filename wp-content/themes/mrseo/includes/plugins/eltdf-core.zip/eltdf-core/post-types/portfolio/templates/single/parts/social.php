<?php if(eltdf_core_portfolio_single_show_share()) : ?>
    <div class="eltdf-ps-info-item eltdf-ps-social-share">
        <?php echo mrseo_elated_get_social_share_html() ?>
    </div>
<?php endif; ?>