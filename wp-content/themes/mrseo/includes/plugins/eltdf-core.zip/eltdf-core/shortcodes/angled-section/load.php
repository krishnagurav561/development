<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/angled-section/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/angled-section/angled-section.php';