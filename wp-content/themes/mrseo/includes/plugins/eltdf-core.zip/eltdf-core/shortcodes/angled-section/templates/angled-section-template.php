<div class="eltdf-angled-section-holder clearfix <?php echo esc_attr($holder_classes);?>" <?php echo mrseo_elated_get_inline_style($holder_style); ?>>
	<div class="eltdf-angled-section" <?php echo mrseo_elated_get_inline_style($angled_holder_style); ?>>
    	<span class="eltdf-as-bckg">
    		<span class="eltdf-angled-bckg-holder" <?php echo mrseo_elated_get_inline_style($angled_style); ?>></span>
    	</span>
    	<div class="eltdf-angled-section-content">
			<?php echo do_shortcode($content); ?>
		</div>
	</div>
</div>