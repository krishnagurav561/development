<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/interactive-image/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/interactive-image/interactive-image.php';