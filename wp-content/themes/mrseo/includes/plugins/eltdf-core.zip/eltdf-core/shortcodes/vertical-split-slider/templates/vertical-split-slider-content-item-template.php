<div class="eltdf-vss-ms-section" <?php echo mrseo_elated_get_inline_attrs($content_data); ?> <?php mrseo_elated_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>