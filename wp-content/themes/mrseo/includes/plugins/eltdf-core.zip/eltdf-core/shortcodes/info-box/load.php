<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/info-box/info-box.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/info-box/functions.php';