<div class="eltdf-team-single-content">
    <h4 class="eltdf-team-single-content-title"><?php esc_html_e('About','eltdf-core')?></h4>
	<?php the_content(); ?>
</div>